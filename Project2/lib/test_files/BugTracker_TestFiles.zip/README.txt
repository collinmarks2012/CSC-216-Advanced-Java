This file contains a listing of test files in the test_files directory.

bug1.xml - Valid bug file
bug2.xml - Negative id
bug3.xml - Missing state
bug4.xml - Missing summary
bug5.xml - Missing reporter
bug6.xml - Missing votes
bug7.xml - File doesn't exist
bug8.xml - Closed bug with no resolution
bug9.xml - Reopen bug that is not confirmed
bug10.xml - Resolved bug with no fixed resolution
bug11.xml - Assigned bug with no owner
bug12.xml - New bug with missing confirmed AND missing votes